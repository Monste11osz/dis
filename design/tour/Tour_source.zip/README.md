# Исходники интерьера, 14.10.2026

Для просмотра используйте готовый Apartment_Tour.html из GitHub. Этот архив нужен для редактирования.

## Структура
- tour/Apartment_detail.blend — готовая сцена Blender 4.3.2, текстуры упакованы внутрь.
- tour/Apartment_detail.glb — модель для браузера, экспорт из той же сцены.
- tour/renders/ — готовые панорамы, заглавный рендер и параметры расчёта.
- tour/build/app.js, tour/shell.html — интерфейс; tour/build_html.py — сборщик одного HTML.
- 3d/variant_A.blend и build_models.py — основа для повторного выполнения build_scene.py.
- web/assets/materials/ — карта ткани и HDRI, CC0.

## Сборка HTML
Нужны Python 3 с Pillow и Node/npm. Из корня архива:
    cd tour/build
    npm ci
    cd ..
    python build_html.py
Результат: tour/Apartment_Tour.html. Готовые панорамы и GLB уже приложены; Blender для этой операции не нужен.

## Редактирование / рендер
Откройте tour/Apartment_detail.blend в Blender 4.3.2. Камеры TOUR_living, TOUR_bedroom, TOUR_kitchen, TOUR_bath, TOUR_hall, TOUR_loggia задают точки обзора. Коллекция 01_FULL_ARCHITECTURE включена, 02_CUTAWAY_ARCHITECTURE выключена для интерьерного рендера.

Для воспроизведения текущего расчёта в Linux x86_64:
    python -m pip install --target tour/python oidn==0.2.1 OpenEXR==3.4.4 numpy
    cd tour
    TOUR_PYTHON=/absolute/path/to/python blender -b Apartment_detail.blend -t 5 --python render_tour.py -- poster living bedroom kitchen bath hall loggia
OIDN запускается в отдельном процессе Python, потому что библиотека TBB может конфликтовать с Blender. Бинарные зависимости в архив не включены. На других ОС используйте встроенный денойзер своей сборки Blender или совместимый OIDN и адаптируйте путь к библиотеке.

После изменения сцены удалите соответствующие renders/*_raw.exr и renders/aux/* из предыдущего расчёта, если они есть: скрипт умеет возобновлять незавершённый рендер и повторно использует существующие RAW.

Экспорт обновлённой свободной модели:
    blender -b --python export_scene.py
Затем заново соберите HTML. build_scene.py полностью пересоздаёт детальную сцену из основы и перезаписывает ручные изменения; для обычной работы редактируйте готовый .blend.

## Проверка
qa/check.cjs проверял HTML в Chromium с отключённой сетью через Playwright setContent: переключение 6 комнат, вращение/масштаб, карту, свободную камеру, срез, диалог и мобильную ширину. Абсолютный путь к установленному Playwright и Chromium в скрипте необходимо заменить на локальные при самостоятельном запуске. Прямая навигация file:// в тестовой среде запрещена политикой браузера, поэтому этим тестом не проверялась. Результат приложен в validation.json.

Это предпроектная концепция. Геометрия, инженерия и отметки требуют обмера, материалы — выбора реальных товаров. См. README.md и SOURCES.md рядом с HTML в репозитории.
