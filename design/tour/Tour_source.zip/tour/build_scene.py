import bpy, math, os, sys, json, importlib.util, random
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent
BASE=P.parent
spec=importlib.util.spec_from_file_location('g',str(BASE/'3d/build_models.py'))
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
bpy.ops.wm.open_mainfile(filepath=str(BASE/'3d/variant_A.blend'))
random.seed(21)
labels={'wall':'Warm white painted plaster','ivory':'Warm ivory','door':'Flush door warm grey','oak':'Natural oak','tile':'Kitchen and hall warm porcelain','tilebath':'Bathroom limestone porcelain','sage':'Dusty sage cabinet paint','stone':'Pale quartz worktop','graphite':'Graphite powdercoat','glass':'Clear architectural glass','metal':'Brushed steel','ceramic':'White ceramic','mirror':'Mirror','linen':'Sand linen weave','bedlinen':'Cotton duvet','sagefabric':'Sage woven textile','sofa':'Oatmeal sofa bouclé','rug':'Woven warm ivory rug','pot':'Clay pot','leaf':'Olive green leaves','screen':'Dark quiet TV screen'}
g.M={k:bpy.data.materials[v] for k,v in labels.items()};M=g.M
FULL=bpy.data.collections['01_FULL_ARCHITECTURE_enable_for_interior'];CUT=bpy.data.collections['02_CUTAWAY_ARCHITECTURE_hide_for_interior']
FULL.hide_render=False;FULL.hide_viewport=False;CUT.hide_render=True;CUT.hide_viewport=True
def remove(prefixes):
 for o in list(bpy.data.objects):
  if any(o.name.startswith(p) for p in prefixes):bpy.data.objects.remove(o,do_unlink=True)
remove(['Sofa','Living rug','Olive accent','Wardrobe','Low TV','43 inch','TV support','Side table leg','Coffee cup','Bed ','Duvet','Sleeping pillow','Sage bed throw','Bedside','Small fabric lamp','Shower','Concealed cistern','Wall hung WC','WC seat','Flush plate','Vanity','Oval basin','Bathroom mirror','Studio ground'])
for o in list(bpy.data.objects):
 if o.name.startswith(('Ceramic planter','Olive leaves')) and 2.3<o.location.x<3.2 and 2.4<o.location.y<3.2:bpy.data.objects.remove(o,do_unlink=True)
for o in list(bpy.data.objects):
 if o.type in {'LIGHT','CAMERA'}:bpy.data.objects.remove(o,do_unlink=True)
def material(name,col,rough=.6,metal=0):return g.mat(name,col,rough,metal)
M['sofa']=material('Tour oatmeal woven sofa',(.59,.53,.43),.87)
M['linen']=material('Tour warm linen',(.69,.63,.53),.93)
M['sagefabric']=material('Tour muted olive woven fabric',(.25,.29,.20),.89)
M['bedlinen']=material('Tour cotton duvet',(.81,.79,.73),.94)
M['rug']=material('Tour soft warm grey rug',(.49,.47,.42),.95)
M['wood']=material('Tour light oak furniture',(.38,.24,.12),.48)
M['taupe']=material('Tour taupe painted cabinet',(.43,.40,.34),.43)
M['white']=material('Tour warm porcelain',(.82,.82,.78),.19)
M['dark']=material('Tour brushed dark bronze',(.055,.046,.035),.33,.65)
M['warm']=material('Tour warm light diffuser',(.88,.80,.65),.4)
bs=M['warm'].node_tree.nodes.get('Principled BSDF');bs.inputs['Emission Color'].default_value=(1,.77,.44,1);bs.inputs['Emission Strength'].default_value=3
def image_node(mat,path,color=True,scale=(1,1,1)):
 n=mat.node_tree.nodes;l=mat.node_tree.links;tc=n.new('ShaderNodeTexCoord');mp=n.new('ShaderNodeVectorMath');mp.operation='MULTIPLY';mp.inputs[1].default_value=scale;l.new(tc.outputs['Generated'],mp.inputs[0]);t=n.new('ShaderNodeTexImage');t.image=bpy.data.images.load(str(path),check_existing=True);t.projection='BOX';t.projection_blend=.12
 if not color:t.image.colorspace_settings.name='Non-Color'
 l.new(mp.outputs[0],t.inputs['Vector']);return t
assets=BASE/'web/assets/materials'
for key in ['sofa','linen','sagefabric','bedlinen','rug']:
 mat=M[key];n=mat.node_tree.nodes;l=mat.node_tree.links;bs=n.get('Principled BSDF')
 tex=image_node(mat,assets/'Fabric036_normal.png',False,(5,5,5));normal=n.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=.22;l.new(tex.outputs['Color'],normal.inputs['Color']);l.new(normal.outputs[0],bs.inputs['Normal'])
 noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=150;noise.inputs['Roughness'].default_value=.75
 bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.15;bump.inputs['Distance'].default_value=.0014;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(normal.outputs[0],bump.inputs['Normal']);l.new(bump.outputs[0],bs.inputs['Normal']);bs.inputs['Sheen Weight'].default_value=.18
def wood(mat,base):
 n=mat.node_tree.nodes;l=mat.node_tree.links;bs=n.get('Principled BSDF');ntex=n.new('ShaderNodeTexNoise');ntex.inputs['Scale'].default_value=5;ntex.inputs['Detail'].default_value=3;ntex.inputs['Roughness'].default_value=.7
 tc=n.new('ShaderNodeTexCoord');mp=n.new('ShaderNodeVectorMath');mp.operation='MULTIPLY';mp.inputs[1].default_value=(1,35,5);l.new(tc.outputs['Generated'],mp.inputs[0]);l.new(mp.outputs[0],ntex.inputs[0])
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(*[c*.70 for c in base],1);ramp.color_ramp.elements[1].color=(*[min(1,c*1.25) for c in base],1);l.new(ntex.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],bs.inputs['Base Color'])
 bump=n.new('ShaderNodeBump');bump.inputs['Distance'].default_value=.0009;bump.inputs['Strength'].default_value=.14;l.new(ntex.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],bs.inputs['Normal'])
wood(M['wood'],(.35,.24,.14))
for i in range(7):
 mat=bpy.data.materials.get('Oak floor shade %s'%i)
 if mat:
  col=(.37+i*.012,.255+i*.01,.155+i*.008);mat.diffuse_color=(*col,1);mat.node_tree.nodes.clear();out=mat.node_tree.nodes.new('ShaderNodeOutputMaterial');bs=mat.node_tree.nodes.new('ShaderNodeBsdfPrincipled');bs.inputs['Roughness'].default_value=.48;mat.node_tree.links.new(bs.outputs[0],out.inputs[0]);wood(mat,col)
# Fine plaster and neutral cabinetry; preserve the original architectural footprint.
for name,col in [('Warm white painted plaster',(.76,.735,.67)),('Warm ivory',(.72,.70,.65)),('Flush door warm grey',(.60,.57,.51)),('Dusty sage cabinet paint',(.36,.36,.30))]:
 m=bpy.data.materials[name];m.diffuse_color=(*col,1);bs=m.node_tree.nodes.get('Principled BSDF')
 for link in list(bs.inputs['Base Color'].links):m.node_tree.links.remove(link)
 bs.inputs['Base Color'].default_value=(*col,1)
 if name=='Warm white painted plaster':bs.inputs['Roughness'].default_value=.84
for o in bpy.data.objects:
 if o.name.startswith(('Kitchen front','Kitchen return front')):o.data.materials.clear();o.data.materials.append(M['taupe'])
 if o.name.startswith(('Natural','Entry shoe','Folding dining','Loggia storage')) and o.type=='MESH':o.data.materials.clear();o.data.materials.append(M['wood'])
 if o.type=='MESH':
  for mod in o.modifiers:
   if mod.type=='BEVEL':mod.segments=5

def box(name,x1,x2,y1,y2,z1,z2,m,bevel=.015):
 o=g.box(name,x1,x2,y1,y2,z1,z2,m,bevel)
 for mod in o.modifiers:
  if mod.type=='BEVEL':mod.segments=8
 return o
def curve(name,pts,radius,m,closed=False):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=radius;cu.bevel_resolution=3
 sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,xyz in zip(sp.points,pts):p.co=(*xyz,1)
 sp.use_cyclic_u=closed;o=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(o);cu.materials.append(m);return o
def pillow(name,loc,dims,m,rotation=(0,0,0),soft=.12):
 o=g.cube(name,loc,dims,m,min(dims)*.40)
 for mod in o.modifiers:
  if mod.type=='BEVEL':mod.segments=10
 o.rotation_euler=rotation
 return o
def plane_cloth(name,origin,w,h,mat,kind='curtain'):
 verts=[];faces=[];nu=80;nv=30
 for j in range(nv+1):
  v=j/nv
  for i in range(nu+1):
   u=i/nu
   if kind=='curtain':
    x=origin[0]+u*w;y=origin[1]+.038*math.sin(u*math.pi*24)*(1+.5*v);z=origin[2]-v*h+.008*math.sin(u*math.pi*7)*v
   else:
    x=origin[0]+u*w;y=origin[1]+v*h;z=origin[2]+.014*math.sin(u*22+v*9)+.009*math.cos(v*35-u*4)
   verts.append((x,y,z))
 for j in range(nv):
  for i in range(nu):
   a=j*(nu+1)+i;faces.append((a,a+1,a+nu+2,a+nu+1))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.materials.append(mat);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 for poly in mesh.polygons:poly.use_smooth=True
 so=o.modifiers.new('Textile thickness','SOLIDIFY');so.thickness=.001
 return o

# Bed: 1400 mm mattress, smaller footprint than the initial A model.
box('Tour bed upholstered frame',.58,2.14,.84,3.00,.12,.36,M['linen'],.075)
box('Tour mattress 140x200',.66,2.06,.92,2.92,.35,.56,M['white'],.07)
box('Tour padded headboard',.53,2.19,2.98,3.065,.10,1.12,M['linen'],.07)
pillow('Tour duvet', (1.36,1.78,.615),(1.40,1.56,.15),M['bedlinen'])
for x in [1.0,1.73]:pillow('Tour sleeping pillow',(x,2.65,.69),(.62,.39,.16),M['linen'],(.08,0,.015))
plane_cloth('Tour bed throw',(.63,1.03,.70),1.47,.48,M['sagefabric'],'throw')
for x in [.32,2.40]:
 g.cyl('Tour round bedside table',(x,2.70,.48),.18,.045,M['wood'])
 g.cyl('Tour bedside pedestal',(x,2.70,.25),.09,.43,M['taupe'])
 g.cyl('Tour bedside lamp base',(x,2.70,.53),.07,.025,M['dark'])
 g.cyl('Tour bedside lamp stem',(x,2.70,.68),.008,.28,M['dark'])
 g.cyl('Tour bedside lamp shade',(x,2.70,.87),.11,.23,M['linen'])
# Window curtains are vertical along the actual west wall, not new facade openings.
for y in [.56,2.32]:
 o=plane_cloth('Tour window linen curtain',(0,0,2.77),.52,2.74,M['linen']);o.rotation_euler.z=math.pi/2;o.location=(.13,y,0)
curve('Tour curtain track',[(2.72,.08,2.78),(2.72,3.01,2.78)],.012,M['ivory'])
o=plane_cloth('Tour sleeping curtain gathered',(0,0,2.76),.54,2.72,M['linen']);o.rotation_euler.z=math.pi/2;o.location=(2.72,2.48,0)

# Low rounded sofa, small table, tactile textiles, clear route from the entrance.
box('Tour sofa plinth',3.10,5.26,.17,.99,.10,.25,M['dark'],.04)
box('Tour sofa soft base',3.06,5.30,.12,1.02,.25,.46,M['sofa'],.09)
box('Tour sofa back',3.11,5.25,.12,.37,.44,.94,M['sofa'],.1)
for x in [3.14,5.22]:box('Tour sofa arm',x-.11,x+.11,.15,1.00,.40,.82,M['sofa'],.10)
for x in [3.69,4.68]:
 pillow('Tour sofa seat cushion',(x,.69,.53),(.91,.68,.22),M['sofa'])
 pillow('Tour sofa back cushion',(x,.36,.78),(.88,.20,.44),M['linen'],(-.12,0,0))
pillow('Tour sofa accent cushion',(3.52,.55,.80),(.42,.19,.42),M['sagefabric'],(-.18,.1,.12))
box('Tour living rug',2.94,5.72,1.02,2.39,.022,.032,M['rug'],.015)
g.cyl('Tour small coffee table',(4.50,1.68,.40),.32,.04,M['wood'])
g.cyl('Tour coffee table pedestal',(4.50,1.68,.21),.105,.36,M['dark'])
for i in range(2):box('Tour book',4.36,4.65,1.55,1.75,.424+i*.024,.445+i*.024,M['ivory'],.003)
g.cyl('Tour vase',(4.55,1.69,.53),.065,.17,M['taupe'])
# Modest wood accent at the existing kitchen/living partition; no fireplace.
box('Tour TV oak backing',3.02,4.39,3.025,3.095,.04,2.77,M['wood'],.004)
for i in range(15):box('Tour fine oak fluting',3.04+i*.089,3.065+i*.089,3.012,3.03,.05,2.77,M['wood'],.004)
box('Tour floating TV cabinet',3.02,4.40,2.72,3.045,.19,.52,M['taupe'],.012)
box('Tour television frame',3.10,4.32,2.965,3.014,1.00,1.705,M['dark'],.01)
box('Tour television screen',3.12,4.30,2.960,2.966,1.02,1.685,M['screen'],.004)
for a,b in [(.14,.73),(.74,1.33),(1.34,1.93)]:
 box('Tour wardrobe carcass',6.31,6.89,a,b,.025,2.72,M['ivory'],.006)
 box('Tour wardrobe handle',6.285,6.312,b-.055,b-.039,.98,1.59,M['dark'],.006)

# Two fine ring pendants echo the reference with realistic compact dimensions.
for cx,cy,rad,z,tilt in [(4.20,1.62,.36,2.47,.10),(4.68,1.67,.25,2.56,-.15)]:
 pts=[(cx+rad*math.cos(i*math.tau/100),cy+rad*math.sin(i*math.tau/100),z+tilt*math.sin(i*math.tau/100)) for i in range(100)]
 curve('Tour bronze pendant ring',pts,.013,M['dark'],True)
 curve('Tour luminous pendant inset',[(x,y,zz-.01) for x,y,zz in pts],.007,M['warm'],True)
 for a in [0,math.tau/3,2*math.tau/3]:curve('Tour pendant cable',[(cx+rad*math.cos(a),cy+rad*math.sin(a),z+tilt*math.sin(a)),(cx+.05*math.cos(a),cy+.05*math.sin(a),2.80)],.0015,M['dark'])
g.cyl('Tour pendant canopy',(4.40,1.65,2.784),.105,.022,M['dark'])

# Kitchen oven in the existing return, practical backsplash, under-cabinet light.
box('Tour oven black frame',2.977,3.008,5.35,5.89,.27,.85,M['dark'],.012)
box('Tour oven glass',2.969,2.978,5.39,5.85,.32,.72,M['screen'],.008)
curve('Tour oven handle',[(2.934,5.40,.77),(2.934,5.84,.77)],.012,M['metal'])
box('Tour kitchen backsplash',1.31,3.64,6.49,6.522,.93,1.54,M['tile'],.001)
box('Tour kitchen light strip',1.38,3.59,6.14,6.18,1.535,1.546,M['warm'],.002)
# Rounded bath loft. All positions remain in the original wet room.
def rounded_ring(cx,cy,w,h,r,z):
 pts=[]
 for sx,sy,start in [(1,1,0),(-1,1,90),(-1,-1,180),(1,-1,270)]:
  center=(cx+sx*(w/2-r),cy+sy*(h/2-r))
  for i in range(12):
   a=math.radians(start+i*90/12);pts.append((center[0]+r*math.cos(a),center[1]+r*math.sin(a),z))
 return pts
cx=5.02;cy=6.12
rings=[rounded_ring(cx,cy,1.70,.70,.10,.58),rounded_ring(cx,cy,1.52,.54,.13,.582),rounded_ring(cx,cy,1.48,.51,.14,.535),rounded_ring(cx,cy,1.25,.36,.13,.18)]
verts=sum(rings,[]);faces=[];N=len(rings[0])
for j in range(3):
 for i in range(N):faces.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
faces.append(tuple(range(3*N,4*N)))
mesh=bpy.data.meshes.new('Bath mesh');mesh.from_pydata(verts,[],faces);mesh.materials.append(M['white']);mesh.update();o=bpy.data.objects.new('Tour bathtub 1700x700',mesh);bpy.context.collection.objects.link(o)
for p in mesh.polygons:p.use_smooth=True
so=o.modifiers.new('Bath body thickness','SOLIDIFY');so.thickness=.012
box('Tour bath front service panel',4.18,5.86,5.755,5.795,.04,.56,M['white'],.014)
box('Tour bath end panel',5.845,5.878,5.80,6.45,.04,.56,M['white'],.015)
g.cyl('Tour bath drain',(4.43,6.12,.185),.027,.009,M['metal'])
curve('Tour bath shower rail',[(4.21,6.20,.75),(4.21,6.20,2.05)],.012,M['metal'])
curve('Tour shower hose',[(4.22,6.11,1.04),(4.24,6.05,.75),(4.23,6.04,1.46)],.008,M['metal'])
box('Tour bath mixer',4.19,4.28,5.97,6.28,.98,1.03,M['metal'],.015)
curve('Tour bath curtain rail',[(4.20,5.77,2.38),(5.85,5.77,2.38)],.009,M['metal'])
plane_cloth('Tour bath curtain gathered',(4.22,5.77,2.37),.27,1.82,M['linen'])
box('Tour vanity cabinet',6.05,6.87,5.99,6.46,.23,.84,M['wood'],.012)
box('Tour vanity top',6.035,6.89,5.97,6.48,.84,.88,M['white'],.01)
# Open ceramic vessel: outer shell, rolled rim, concave inner wall and drain.
rings=[(.18,.09,.884),(.25,.145,.916),(.285,.175,.973),(.284,.174,.986),(.264,.154,.986),(.258,.148,.972),(.224,.12,.936),(.16,.075,.911),(.032,.032,.904)]
verts=[(6.45+rx*math.cos(i*math.tau/80),6.20+ry*math.sin(i*math.tau/80),z) for rx,ry,z in rings for i in range(80)]
faces=[(j*80+i,j*80+(i+1)%80,(j+1)*80+(i+1)%80,(j+1)*80+i) for j in range(len(rings)-1) for i in range(80)]
faces.append(tuple((len(rings)-1)*80+i for i in range(80)))
mesh=bpy.data.meshes.new('Ceramic vessel open bowl');mesh.from_pydata(verts,[],faces);mesh.materials.append(M['white']);mesh.update()
basin=bpy.data.objects.new('Tour washbasin concave bowl',mesh);bpy.context.collection.objects.link(basin)
for face in mesh.polygons:face.use_smooth=True
g.cyl('Tour washbasin drain',(6.45,6.20,.906),.023,.004,M['metal'])
g.cyl('Tour basin tap',(6.45,6.39,1.03),.018,.25,M['metal'])
curve('Tour basin tap spout',[(6.45,6.39,1.15),(6.45,6.25,1.15)],.018,M['metal'])
box('Tour bath mirror',6.07,6.85,6.505,6.52,1.08,2.18,M['mirror'],.018)
box('Tour mirror warm light',6.13,6.79,6.48,6.50,2.20,2.215,M['warm'],.003)
g.sphere('Tour toilet pedestal',(6.53,5.30,.21),(.20,.18,.21),M['white'])
g.sphere('Tour toilet bowl',(6.43,5.30,.38),(.34,.22,.15),M['white'])
curve('Tour toilet seat',[(6.39+.285*math.cos(i*math.tau/64),5.30+.192*math.sin(i*math.tau/64),.505) for i in range(64)],.025,M['white'],True)
g.sphere('Tour toilet inner shadow',(6.38,5.30,.492),(.24,.14,.012),material('Tour pale basin interior',(.38,.44,.43),.23))
box('Tour toilet cistern',6.69,6.87,5.07,5.53,.45,.86,M['white'],.04)
g.cyl('Tour toilet flush button',(6.78,5.30,.871),.025,.009,M['metal'])

# Bathroom wall tiles, laid out rather than a featureless single colour.
tilem=material('Tour matte greige wall tile',(.53,.51,.45),.52)
noise=tilem.node_tree.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=90
bump=tilem.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Distance'].default_value=.001;bump.inputs['Strength'].default_value=.13;tilem.node_tree.links.new(noise.outputs['Fac'],bump.inputs['Height']);tilem.node_tree.links.new(bump.outputs[0],tilem.node_tree.nodes.get('Principled BSDF').inputs['Normal'])
for iz in range(5):
 z1=.02+iz*.56;z2=min(2.79,z1+.557)
 for ix in range(5):
  x1=4.125+ix*.56;x2=min(6.935,x1+.557)
  if x2>x1:box('Tour north bathroom tile',x1,x2,6.510,6.525,z1,z2,tilem,.001)
 for iy in range(4):
  y1=4.715+iy*.50;y2=min(6.525,y1+.497)
  if y2>y1:
   box('Tour east bathroom tile',6.925,6.938,y1,y2,z1,z2,tilem,.001)
   box('Tour west bathroom tile',4.122,4.136,y1,y2,z1,z2,tilem,.001)

# Doors get tactile hardware; 2600 mm leaves are retained from the original scene.
for name,loc,axis in [('bath',(5.69,4.61,1.04),'X'),('living',(5.79,2.69,1.04),'X'),('kitchen',(4.43,4.25,1.04),'Y')]:
 x,y,z=loc
 if axis=='X':curve('Tour door handle '+name,[(x,y,z),(x-.115,y,z)],.009,M['dark'])
 else:curve('Tour door handle '+name,[(x,y,z),(x,y-.115,z)],.009,M['dark'])
# Skirtings; avoid door/window openings in the main living space.
for name,a,b,c,d in [('living south',.02,6.90,.02,.036),('living east',6.91,6.928,.02,2.65),('kitchen wall',1.30,4.40,3.065,3.083)]:box('Tour skirting '+name,a,b,c,d,.018,.09,M['ivory'],.002)

ceilcol=bpy.data.collections.new('03_CEILINGS');bpy.context.scene.collection.children.link(ceilcol)
for name,poly in [('LIVING',g.ROOM),('KITCHEN',g.KITCHEN),('BATH',g.BATH),('HALL',g.HALL),('LOGGIA',g.LOGGIA)]:
 mesh=bpy.data.meshes.new('Ceiling '+name);mesh.from_pydata([(x,y,2.80) for x,y in poly],[],[list(reversed(range(len(poly))))]);mesh.materials.append(M['wall']);mesh.update();o=bpy.data.objects.new('Tour ceiling '+name,mesh);ceilcol.objects.link(o)

def area_light(name,loc,target,energy,size,color=(1,.86,.67),shape='DISK',size_y=None):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=energy;o.data.shape=shape;o.data.size=size;o.data.color=color
 if size_y is not None:o.data.size_y=size_y
 o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();return o
area_light('Daylight through living window',(-.21,1.72,1.76),(3,1.50,1.0),450,1.90,(.83,.90,1),'RECTANGLE',1.70)
area_light('Daylight through loggia',(-.22,4.98,1.8),(3.25,5.15,1.2),650,2.25,(.85,.91,1),'RECTANGLE',1.8)
area_light('Living diffuse pendant',(4.4,1.65,2.62),(4.4,1.65,0),85,1.0)
area_light('Bed soft ceiling',(1.3,1.7,2.73),(1.3,1.7,0),45,.9)
area_light('Kitchen ceiling',(2.70,4.75,2.73),(2.70,4.75,0),95,.85)
area_light('Kitchen counter light',(2.48,6.09,1.51),(2.48,6.05,.90),18,1.85,(1,.87,.69),'RECTANGLE',.09)
area_light('Bath ceiling',(5.50,5.55,2.73),(5.50,5.55,0),115,.95)
area_light('Hall ceiling',(5.55,3.70,2.73),(5.55,3.70,0),80,.8)
for name,x,y,r in [('bed',1.30,1.65,.17),('kitchen',2.65,4.78,.18),('bath',5.45,5.46,.16),('hall',5.54,3.66,.14)]:g.cyl('Tour ceiling diffuser '+name,(x,y,2.76),r,.025,M['warm'])
scene=bpy.context.scene;world=bpy.data.worlds.new('Tour daylight environment');world.use_nodes=True;scene.world=world
n=world.node_tree.nodes;l=world.node_tree.links;n.clear();out=n.new('ShaderNodeOutputWorld');bg=n.new('ShaderNodeBackground');env=n.new('ShaderNodeTexEnvironment');env.image=bpy.data.images.load(str(assets/'venice_sunset_1k.hdr'),check_existing=True);bg.inputs['Strength'].default_value=.35;l.new(env.outputs[0],bg.inputs[0]);l.new(bg.outputs[0],out.inputs[0])
# Neutral background through windows: lighting HDRI is not a claimed view of Astana.
for x,y,w,h in [(-1.5,1.70,3.2,4),(-1.5,4.96,3.5,4)]:
 o=box('Tour neutral exterior light card',x-.01,x+.01,y-w/2,y+w/2,0,h,material('Tour exterior sky '+str(y),(.64,.71,.77),.95),0)
 o.visible_shadow=False
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=40;scene.cycles.use_denoising=False;scene.cycles.adaptive_threshold=.035;scene.cycles.max_bounces=6;scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=3;scene.cycles.transmission_bounces=4
scene.render.threads_mode='FIXED';scene.render.threads=5;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='JPEG';scene.render.image_settings.quality=94;scene.render.image_settings.color_mode='RGB';scene.render.film_transparent=False
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=-.10
views=[
 {'id':'living','label':'Гостиная','pos':[5.48,1.84,1.48],'target':[3.15,1.85,1.35]},
 {'id':'bedroom','label':'Спальная зона','pos':[2.55,.58,1.47],'target':[1.22,2.18,1.05]},
 {'id':'kitchen','label':'Кухня','pos':[2.03,4.39,1.49],'target':[3.15,5.78,1.25]},
 {'id':'bath','label':'Ванная','pos':[5.43,5.04,1.48],'target':[5.60,6.12,1.23]},
 {'id':'hall','label':'Прихожая','pos':[5.48,3.77,1.49],'target':[6.5,4.37,1.35]},
 {'id':'loggia','label':'Лоджия','pos':[.62,4.78,1.48],'target':[.70,6.1,1.2]},
]
for v in views:
 bpy.ops.object.camera_add(location=v['pos']);c=bpy.context.object;c.name='TOUR_'+v['id'];c.rotation_euler=(Vector(v['target'])-c.location).to_track_quat('-Z','Y').to_euler();c.data.type='PERSP';c.data.lens=21;c.data.clip_start=.03;c.data.clip_end=100
scene.camera=bpy.data.objects['TOUR_living'];scene['tour_note']='Concept based on approximate original plan; original kitchen, bathtub, fixed bed, 2600mm door leaves. New furnishings and palette from reference, not a surveyed construction model.'
scene['clean_height_assumption_m']=2.80
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=str(P/'Apartment_detail.blend'))
(P/'views.json').write_text(json.dumps(views,ensure_ascii=False,indent=2))
print('SCENE_READY',len(bpy.data.objects),flush=True)
if '--preview' in sys.argv:
 scene.cycles.samples=12;scene.render.resolution_x=1100;scene.render.resolution_y=760;scene.render.filepath=str(P/'renders/preview.jpg');bpy.ops.render.render(write_still=True)
