"""Build the self-contained viewer. Requires final JPEGs for all six viewpoints."""
from pathlib import Path
import base64, json, subprocess, io, argparse
from PIL import Image

P=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=P/'Apartment_Tour.html')
parser.add_argument('--development',action='store_true',help='Temporary interface QA only; never distribute')
args=parser.parse_args()
assets=P.parent/'web/assets/materials'
def raw(path): return base64.b64encode(path.read_bytes()).decode()
def url(path,mime):return 'data:'+mime+';base64,'+raw(path)
views=json.loads((P/'views.json').read_text())
data={'views':views,'panoramas':{},'thumbnails':{},'poster':url(P/'renders/poster.jpg','image/jpeg'),
      'model':raw(P/'Apartment_detail.glb'),'fabricNormal':url(assets/'Fabric036_normal.png','image/png'),
      'hdri':url(assets/'venice_sunset_1k.hdr','application/octet-stream')}
for v in views:
    p=P/'renders'/f"{v['id']}.jpg"
    if not p.exists() and args.development:p=P/'renders/poster.jpg'
    if not p.exists():raise SystemExit('Missing final panorama: '+str(p))
    im=Image.open(p)
    if not args.development:assert im.width==2*im.height,(p,im.size)
    data['panoramas'][v['id']]=url(p,'image/jpeg')
    im.thumbnail((240,120));b=io.BytesIO();im.save(b,format='JPEG',quality=80)
    data['thumbnails'][v['id']]='data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
subprocess.run([str(P/'build/node_modules/.bin/esbuild'),'app.js','--bundle','--format=iife','--minify','--outfile=app.bundle.js'],cwd=P/'build',check=True)
script=(P/'build/app.bundle.js').read_text().replace('</script','<\\/script')
license=(P/'build/node_modules/three/LICENSE').read_text()
html=(P/'shell.html').read_text()
if args.development:html=html.replace('Санды-кала 2','ТЕСТ — НЕ ДЛЯ ПУБЛИКАЦИИ')
html=html.replace('</body>','<!-- Three.js license\n'+license+'\n-->\n<script id="project-data" type="application/json">'+json.dumps(data,ensure_ascii=False,separators=(',',':'))+'</script>\n<script>'+script+'</script>\n</body>')
html='\n'.join(line.rstrip() for line in html.splitlines())+'\n'
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(html)
print(json.dumps({'file':str(args.output),'bytes':args.output.stat().st_size,'views':len(views),'development':args.development}))
