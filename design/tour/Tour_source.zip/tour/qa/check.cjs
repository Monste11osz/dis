const {chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const fs=require('fs');
(async()=>{
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage']});
try {
const context=await browser.newContext({viewport:{width:1280,height:900},offline:true});
const page=await context.newPage();page.setDefaultTimeout(90000);const errors=[],requests=[];
page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
await page.setContent(fs.readFileSync(process.argv[2]||'test.html','utf8'),{waitUntil:'load',timeout:120000});
await page.waitForFunction(()=>window.__tourState?.loaded,{},{timeout:120000});

console.log('Loaded panorama');await page.screenshot({path:'qa/desktop.jpg'});
const initial=await page.evaluate(()=>window.__cameraSnapshot());
await page.mouse.move(700,500);await page.mouse.down();await page.mouse.move(1000,540,{steps:5});await page.mouse.up();
const moved=await page.evaluate(()=>window.__cameraSnapshot());
if(initial.yaw===moved.yaw)throw Error('Panorama drag did not move');
await page.locator('#zoom-in').click();const zoomed=await page.evaluate(()=>window.__cameraSnapshot());if(zoomed.fov>=moved.fov)throw Error('Zoom failed');
for(const id of ['bedroom','kitchen','bath','hall','loggia','living']){await page.locator(`[data-room="${id}"]`).click();await page.waitForFunction(id=>window.__tourState.room===id&&document.getElementById('loading').hidden,id);}
await page.locator('#map-toggle').click();await page.locator('[data-point="bath"]').click();await page.waitForFunction(()=>window.__tourState.room==='bath'&&document.getElementById('loading').hidden);await page.locator('#map-close').click();await page.screenshot({path:'qa/bath.jpg'});
console.log('Rooms and map passed');await page.locator('#mode-model').click();await page.waitForFunction(()=>window.__tourState.mode==='model'&&document.getElementById('loading').hidden);await page.waitForTimeout(1000);await page.screenshot({path:'qa/model.jpg'});
const orbit0=await page.evaluate(()=>window.__cameraSnapshot());await page.mouse.move(720,500);await page.mouse.down();await page.mouse.move(920,540,{steps:8});await page.mouse.up();await page.waitForTimeout(1000);const orbit1=await page.evaluate(()=>window.__cameraSnapshot());if(JSON.stringify(orbit0)===JSON.stringify(orbit1))throw Error('3D orbit failed');
console.log('Orbit passed');await page.locator('#top').click();await page.waitForTimeout(800);await page.screenshot({path:'qa/top.jpg'});await page.locator('#cut').click();if((await page.evaluate(()=>window.__tourState.cut)))throw Error('Cut toggle failed');
await page.locator('[data-room="kitchen"]').click();await page.waitForTimeout(800);await page.screenshot({path:'qa/kitchen-model.jpg'});
await page.locator('#mode-tour').click();await page.waitForFunction(()=>document.getElementById('loading').hidden);await page.screenshot({path:'qa/kitchen.jpg'});
await page.locator('#info').click();if(!await page.locator('#about').evaluate(el=>el.open))throw Error('Dialog failed');await page.locator('#info-close').click();
console.log('Desktop passed');await page.setViewportSize({width:390,height:844});await page.waitForTimeout(800);await page.locator('[data-room="living"]').click();await page.waitForFunction(()=>document.getElementById('loading').hidden);await page.screenshot({path:'qa/mobile.jpg'});
const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);if(overflow)throw Error('Mobile page overflows');
const report={date:new Date().toISOString(),file:require('path').basename(process.argv[2]||'test.html'),browser:await browser.version(),desktopViewport:[1280,900],mobileViewport:[390,844],loadMethod:'Playwright setContent; offline context; direct file navigation not tested',errors,externalRequests:requests,panoramaDrag:true,zoom:true,sixRooms:true,map:true,modelOrbit:true,cut:true,dialog:true,mobileNoOverflow:true,offline:true};fs.writeFileSync('qa/validation.json',JSON.stringify(report,null,2));console.log(report);if(errors.length||requests.length)throw Error('Browser errors or external requests');
} finally {await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
