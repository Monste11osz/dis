"""Cycles panoramas with Open Image Denoise, no generative geometry alteration.
Blender -b Apartment_detail.blend -t 5 --python render_tour.py -- living kitchen ...
The PyPI oidn==0.2.1 binding provides Intel OIDN 1.4.3 under Apache 2.0.
"""
import bpy, sys, math, json, time, subprocess, os
import numpy as np
from pathlib import Path
P=Path(__file__).resolve().parent
scene=bpy.context.scene
scene.cycles.use_denoising=False
scene.render.threads_mode='FIXED';scene.render.threads=5
scene.render.image_settings.file_format='OPEN_EXR';scene.render.image_settings.color_mode='RGBA';scene.render.image_settings.color_depth='32';scene.render.image_settings.exr_codec='ZIP'
scene.view_layers[0].use_pass_normal=True;scene.view_layers[0].use_pass_diffuse_color=True
scene.use_nodes=True;n=scene.node_tree.nodes;n.clear();links=scene.node_tree.links
rl=n.new('CompositorNodeRLayers');out=n.new('CompositorNodeComposite');links.new(rl.outputs['Image'],out.inputs[0])
aux=n.new('CompositorNodeOutputFile');aux.base_path=str(P/'renders/aux');aux.format.file_format='OPEN_EXR';aux.format.color_mode='RGB';aux.format.color_depth='32';aux.format.exr_codec='ZIP'
aux.file_slots.clear();aux.file_slots.new('normal');aux.file_slots.new('albedo');links.new(rl.outputs['Normal'],aux.inputs['normal']);links.new(rl.outputs['DiffCol'],aux.inputs['albedo'])
def load_pixels(path):
 img=bpy.data.images.load(str(path),check_existing=False);w,h=img.size;pixels=np.empty(w*h*4,dtype=np.float32);img.pixels.foreach_get(pixels);bpy.data.images.remove(img);return np.ascontiguousarray(pixels.reshape(h,w,4)[:,:,:3])
def denoise(path,w,h,name):
 host_python=os.environ.get('TOUR_PYTHON','/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python')
 subprocess.run([host_python,str(P/'denoise_exr.py'),name],check=True)
 output=load_pixels(P/'renders'/f'{name}_clean.exr')
 image=bpy.data.images.new(name+'_denoised',width=w,height=h,float_buffer=True,alpha=True)
 rgba=np.ones((h,w,4),dtype=np.float32);rgba[:,:,:3]=output;image.pixels.foreach_set(rgba.ravel())
 scene.render.image_settings.file_format='JPEG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.quality=95
 dest=P/'renders'/f'{name}.jpg';image.save_render(str(dest),scene=scene);bpy.data.images.remove(image)
 scene.render.image_settings.file_format='OPEN_EXR';scene.render.image_settings.color_mode='RGBA';scene.render.image_settings.color_depth='32'
 print('DENOISED',name,dest.stat().st_size,flush=True)
 return dest
names=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['living','bedroom','kitchen','bath','hall','loggia']
for name in names:
 start=time.time();still=name=='poster';view='living' if still else name;camera=bpy.data.objects['TOUR_'+view];scene.camera=camera
 if still:w,h,samples=1500,1000,24;camera.data.type='PERSP';camera.data.lens=22
 else:
  camera.data.type='PANO';camera.data.panorama_type='EQUIRECTANGULAR';camera.rotation_euler=(math.pi/2,0,0)
  w,h,samples=(3072,1536,16) if view=='living' else (2560,1280,16) if view in ['bedroom','kitchen','bath'] else (2048,1024,12)
 scene.render.resolution_x=w;scene.render.resolution_y=h;scene.cycles.samples=samples;scene.cycles.adaptive_threshold=.045
 aux.file_slots[0].path=name+'_normal';aux.file_slots[1].path=name+'_albedo'
 scene.render.filepath=str(P/'renders'/f'{name}_raw.exr')
 if not Path(scene.render.filepath).exists():bpy.ops.render.render(write_still=True)
 denoise(Path(scene.render.filepath),w,h,name)
 report={'id':name,'width':w,'height':h,'samples':samples,'seconds':round(time.time()-start,1),'renderer':'Blender Cycles CPU','denoise':'Intel OIDN 1.4.3, color + normal + diffuse albedo','camera_source':'Apartment_detail.blend'}
 (P/'renders'/f'{name}.json').write_text(json.dumps(report,indent=2));print('FINISHED',json.dumps(report),flush=True)
