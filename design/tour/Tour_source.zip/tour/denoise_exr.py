"""Renderer postprocessing in an isolated process to avoid Blender/TBB conflicts."""
from pathlib import Path
import sys,ctypes
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'python'))
import numpy as np, OpenEXR, oidn
name=sys.argv[1]
def read(path):
 f=OpenEXR.File(str(path));channels=f.channels()
 if all(k in channels for k in ('X','Y','Z')): arr=np.stack([channels[k].pixels for k in ('X','Y','Z')],axis=-1)
 else: arr=channels['RGB' if 'RGB' in channels else 'RGBA'].pixels[:,:,:3]
 return np.ascontiguousarray(arr,dtype=np.float32)
color=read(P/'renders'/f'{name}_raw.exr');normal=read(P/'renders/aux'/f'{name}_normal0001.exr');albedo=read(P/'renders/aux'/f'{name}_albedo0001.exr');output=np.zeros_like(color);h,w,_=color.shape
lib=ctypes.CDLL(str(P/'python/oidn/lib.linux.x64/libOpenImageDenoise.so.1.4.3'))
sb=lib.oidnSetFilter1b;sb.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_bool];sb.restype=None
si=lib.oidnSetDevice1i;si.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];si.restype=None
d=oidn.NewDevice();si(d,b'numThreads',5);oidn.CommitDevice(d);f=oidn.NewFilter(d,'RT')
for key,arr in [('color',color),('normal',normal),('albedo',albedo),('output',output)]:oidn.SetSharedFilterImage(f,key,arr,oidn.FORMAT_FLOAT3,w,h)
sb(f,b'hdr',True);sb(f,b'cleanAux',False);oidn.CommitFilter(f);oidn.ExecuteFilter(f);err=oidn.GetDeviceError(d);assert err==0,err
oidn.ReleaseFilter(f);oidn.ReleaseDevice(d)
assert np.isfinite(output).all()
OpenEXR.File({'compression':OpenEXR.ZIP_COMPRESSION,'type':OpenEXR.scanlineimage},{'RGB':output}).write(str(P/'renders'/f'{name}_clean.exr'))
print('OIDN_OK',name,w,h,flush=True)
