import bpy, importlib.util, json
from pathlib import Path
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'Apartment_detail.blend'))
for c in bpy.data.collections:c.hide_viewport=False;c.hide_render=False
for o in bpy.data.objects:o.hide_set(False);o.hide_viewport=False;o.hide_render=False
for o in list(bpy.data.objects):
 if o.type not in {'MESH','CURVE'} or o.name.startswith('Tour neutral exterior'):bpy.data.objects.remove(o,do_unlink=True)
groups={}
for name in ['FULL_ARCHITECTURE','CUTAWAY_ARCHITECTURE','FURNITURE','CEILINGS']:
 o=bpy.data.objects.new(name,None);bpy.context.scene.collection.objects.link(o);groups[name]=o
for o in list(bpy.data.objects):
 if o.type not in {'MESH','CURVE'}:continue
 cs=[c.name for c in o.users_collection]
 role='FULL_ARCHITECTURE' if any('01_FULL' in s for s in cs) else 'CUTAWAY_ARCHITECTURE' if any('02_CUT' in s for s in cs) else 'CEILINGS' if any('03_CEIL' in s for s in cs) else 'FURNITURE'
 o.parent=groups[role]
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 if o.type=='CURVE':bpy.ops.object.convert(target='MESH')
 for mod in list(o.modifiers):
  if mod.type=='BEVEL':mod.segments=min(5,mod.segments)
  try:bpy.ops.object.modifier_apply(modifier=mod.name)
  except RuntimeError:pass
 uv=o.data.uv_layers.active or o.data.uv_layers.new(name='MetricUV')
 nm=o.matrix_world.to_3x3().inverted().transposed()
 for face in o.data.polygons:
  normal=(nm@face.normal).normalized();dominant=max(range(3),key=lambda i:abs(normal[i]))
  for ix in face.loop_indices:
   p=o.matrix_world@o.data.vertices[o.data.loops[ix].vertex_index].co
   uv.data[ix].uv=(p.x,p.y) if dominant==2 else (p.x,p.z) if dominant==1 else (p.y,p.z)
for m in bpy.data.materials:
 color=tuple(m.diffuse_color);bs=m.node_tree.nodes.get('Principled BSDF') if m.use_nodes else None
 rough=bs.inputs['Roughness'].default_value if bs else .6;metal=bs.inputs['Metallic'].default_value if bs else 0
 m.use_nodes=True;m.node_tree.nodes.clear();out=m.node_tree.nodes.new('ShaderNodeOutputMaterial');bs=m.node_tree.nodes.new('ShaderNodeBsdfPrincipled')
 bs.inputs['Base Color'].default_value=color;bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
 if 'glass' in m.name.lower():bs.inputs['Alpha'].default_value=.18;m.surface_render_method='BLENDED'
 m.node_tree.links.new(bs.outputs[0],out.inputs[0]);m.use_backface_culling=False
for role,root in groups.items():
 batches={}
 for o in list(root.children):batches.setdefault(tuple(m.name for m in o.data.materials),[]).append(o)
 for key,objects in batches.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objects:o.select_set(True)
  bpy.context.view_layer.objects.active=objects[0]
  if len(objects)>1:bpy.ops.object.join()
  objects[0].name=role+' / '+' + '.join(key)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=str(P/'Apartment_detail.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_cameras=False,export_lights=False,export_animations=False)
print('GLB', (P/'Apartment_detail.glb').stat().st_size,'meshes',sum(o.type=='MESH' for o in bpy.data.objects),flush=True)
