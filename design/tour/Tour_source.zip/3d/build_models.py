import bpy, math, os, random
from mathutils import Vector
random.seed(41)
OUT='/workspace/apartment_design/3d'
H=2.86
ROOM=[(0,0),(6.94,0),(6.94,2.69),(4.43,2.69),(4.43,3.10),(0,3.10)]
KITCHEN=[(1.29,3.22),(4.43,3.22),(4.43,4.59),(3.65,4.59),(3.65,6.53),(1.29,6.53)]
BATH=[(4.12,4.71),(6.94,4.71),(6.94,6.53),(4.12,6.53)]
HALL=[(4.55,2.81),(6.94,2.81),(6.94,4.60),(4.55,4.60)]
LOGGIA=[(0,3.39),(1.21,3.39),(1.21,6.53),(0,6.53)]
M={}

def mat(name,color,rough=.5,metal=0,trans=0):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
    b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal
    b.inputs['Transmission Weight'].default_value=trans
    return m

def natural(name,col,scale,rough=.6,strength=.025,wood=False):
    m=mat(name,col,rough);n=m.node_tree.nodes;l=m.node_tree.links;b=n.get('Principled BSDF')
    tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=scale;tex.inputs['Detail'].default_value=2.5
    coord=n.new('ShaderNodeTexCoord');mapping=n.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(1,25,6) if wood else (1,1,1)
    l.new(coord.outputs['Generated'],mapping.inputs[0]);l.new(mapping.outputs[0],tex.inputs['Vector'])
    ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.12;ramp.color_ramp.elements[0].color=(*[c*.80 for c in col],1);ramp.color_ramp.elements[1].position=.86;ramp.color_ramp.elements[1].color=(*[min(c*1.14,1) for c in col],1)
    l.new(tex.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],b.inputs['Base Color'])
    bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.20;bump.inputs['Distance'].default_value=strength;l.new(tex.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],b.inputs['Normal'])
    return m

def cube(name,loc,size,material,bevel=0,col=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if material:o.data.materials.append(material)
    if bevel:
        mod=o.modifiers.new('Soft edges','BEVEL');mod.width=bevel;mod.segments=3
        o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    if col:
        for c in list(o.users_collection):c.objects.unlink(o)
        col.objects.link(o)
    return o

def box(name,x1,x2,y1,y2,z1,z2,material,bevel=0,col=None):return cube(name,((x1+x2)/2,(y1+y2)/2,(z1+z2)/2),(x2-x1,y2-y1,z2-z1),material,bevel,col)

def cyl(name,loc,r,depth,material,verts=48):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(material)
    bev=o.modifiers.new('Rounded edges','BEVEL');bev.width=.012;bev.segments=3;o.modifiers.new('Normals','WEIGHTED_NORMAL');return o

def sphere(name,loc,scale,material):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=1,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(material)
    for p in o.data.polygons:p.use_smooth=True
    return o

def polyfloor(name,poly,z,material):
    mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,y,z)for x,y in poly],[],[list(range(len(poly)))]);mesh.materials.append(material);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
    s=o.modifiers.new('Floor slab','SOLIDIFY');s.thickness=.10;return o

def wall(name,x1,x2,y1,y2,height=H,cut=.80,z=0,material=None):
    material=material or M['wall'];box(name+' FULL',x1,x2,y1,y2,z,height,material,.006,FULL)
    if cut>z:box(name+' CUT',x1,x2,y1,y2,z,min(cut,height),material,.006,CUT)

def door(name,x1,x2,y1,y2,orientation='Y',material=None,leaf_h=2.60,rough_h=2.64):
    # Interior leaf2600mm; rough opening2640 only a schematic input, never a construction instruction.
    ma=material or M['door'];box(name+' leaf FULL',x1,x2,y1,y2,.012,.012+leaf_h,ma,.006,FULL)
    box(name+' leaf CUT',x1,x2,y1,y2,.012,.78,ma,.006,CUT)
    if orientation=='Y':
        xx=(x1+x2)/2
        for yy in [y1-.025,y2+.025]:wall(name+' jamb',xx-.065,xx+.065,yy-.025,yy+.025,rough_h,.80,material=M['oak'])
        wall(name+' lintel',xx-.065,xx+.065,y1-.05,y2+.05,H,0,z=rough_h)
    else:
        yy=(y1+y2)/2
        for xx in [x1-.025,x2+.025]:wall(name+' jamb',xx-.025,xx+.025,yy-.065,yy+.065,rough_h,.80,material=M['oak'])
        wall(name+' lintel',x1-.05,x2+.05,yy-.065,yy+.065,H,0,z=rough_h)

def architecture(v):
    # Floor boundaries follow dimensions visible on the supplied scan; junctions are schematic.
    for name,p,m in [('Living / bedroom',ROOM,M['oakfloor']),('Kitchen',KITCHEN,M['tile']),('Bathroom',BATH,M['tilebath']),('Hall',HALL,M['tile']),('Isolated loggia',LOGGIA,M['tilelog'])]:polyfloor(name,p,0,m)
    # Individual oak boards with subtle shade variation.
    for row in range(18):
        y0=row*.18;y1=min(y0+.178,3.10)
        xmax=6.94 if y0<2.69 else 4.43
        if y0>=3.10:continue
        if y1>2.69 and y0<2.69:y1=2.688
        x=-1.2+(row%3)*.40
        while x<xmax:
            a=max(x,0);b=min(x+1.196,xmax)
            if b>a:box('Oak flooring board',a,b,y0,y1,.003,.016,random.choice(M['boards']))
            x+=1.2
    # Exterior envelope: the far walls stay high for architectural context.
    wall('South exterior',-.16,7.10,-.16,0,cut=.24)
    wall('East exterior lower',6.94,7.10,0,3.20,cut=1.20)
    wall('East exterior upper',6.94,7.10,4.20,6.69,cut=H)
    wall('North exterior',-.16,6.94,6.53,6.69,cut=H)
    wall('West solid lower',-.16,0,0,.70,cut=.30)
    wall('West solid middle',-.16,0,2.70,3.60,cut=.30)
    wall('West solid top',-.16,0,6.30,6.53,cut=.30)
    # Existing living-room window, the only direct external window in this room.
    wall('Living window sill',-.16,0,.70,2.70,height=.85,cut=.85)
    wall('Living window head',-.16,0,.70,2.70,height=H,cut=0,z=2.67)
    box('Living window glass FULL',-.087,-.075,.73,2.67,.89,2.62,M['glass'],0,FULL)
    box('Living window glass CUT',-.087,-.075,.73,2.67,.89,1.18,M['glass'],0,CUT)
    wall('Living window bottom frame',-.12,-.04,.71,2.69,.91,.91,z=.85,material=M['frame'])
    for yy in [.71,1.70,2.69]:wall('Living window vertical frame',-.12,-.04,yy-.025,yy+.025,2.65,1.20,z=.85,material=M['frame'])
    # Glazed but thermally independent loggia; not integrated into the heated interior.
    wall('Loggia parapet',-.16,0,3.60,6.30,height=.82,cut=.82)
    box('Loggia exterior glass FULL',-.087,-.075,3.62,6.28,.86,2.67,M['glass'],0,FULL)
    box('Loggia exterior glass CUT',-.087,-.075,3.62,6.28,.86,1.18,M['glass'],0,CUT)
    wall('Loggia window bottom frame',-.12,-.04,3.62,6.28,.89,.89,z=.83,material=M['frame'])
    for yy in [3.62,4.50,5.40,6.28]:wall('Loggia frame',-.12,-.04,yy-.022,yy+.022,2.69,1.20,z=.83,material=M['frame'])
    wall('Loggia southern boundary',0,1.29,3.10,3.39,cut=.80)
    wall('Loggia divider lower',1.21,1.29,3.39,4.0,cut=.80)
    wall('Loggia divider upper',1.21,1.29,5.90,6.53,cut=.80)
    box('Loggia glazing FULL',1.24,1.26,4.04,5.86,.10,2.64,M['glass'],0,FULL)
    for yy in [4.03,4.85,5.87]:wall('Loggia door-window frame',1.20,1.30,yy-.024,yy+.024,2.67,.80,material=M['frame'])
    # Core enclosure, including an uncertain thick junction, not identified as a shaft.
    wall('Unmeasured kitchen bath junction',3.65,4.12,4.59,6.53,cut=.90)
    wall('Bathroom south left',4.12,5.00,4.60,4.71,cut=.80)
    wall('Bathroom south right',5.80,6.94,4.60,4.71,cut=.80)
    wall('Kitchen hall lower',4.43,4.55,3.22,3.55,cut=.80)
    wall('Kitchen hall upper',4.43,4.55,4.40,4.60,cut=.80)
    wall('Living notch west',4.43,4.55,2.69,3.22,cut=.80)
    wall('Living hall west',4.43,5.00,2.69,2.81,cut=.80)
    wall('Living hall east',5.90,6.94,2.69,2.81,cut=.80)
    if v=='A':wall('Kitchen room original partition',1.29,4.43,3.10,3.22,cut=.80)
    else:wall('Kitchen room retained partition',1.29,3.10,3.10,3.22,cut=.80)
    # Doorways remain clear in the cutaway, with full doors stored in hidden architecture.
    door('Bathroom2600',5.00,5.80,4.645,4.69,'X')
    door('Kitchen',4.47,4.51,3.58,4.37)
    door('Living room',5.03,5.87,2.725,2.765,'X')
    door('Entrance existing height schematic',6.985,7.04,3.24,4.16,material=M['graphite'],leaf_h=2.20,rough_h=2.25)
    if v=='B':
        wall('New bedroom partition lower',3.0,3.1,0,.15,cut=1.05)
        wall('New bedroom partition upper',3.0,3.1,1.05,3.10,cut=1.05)
        door('Bedroom2600',3.035,3.07,.20,1.00)
    elif v=='C':
        # Light-transmitting separation; not a claim of an approved second habitable room.
        for yy in [.05,1.05,2.06,3.05]:wall('Glass partition upright',3.025,3.065,yy-.014,yy+.014,H,1.25,material=M['frame'])
        box('Glass partition FULL',3.042,3.05,1.07,3.05,.02,H-.025,M['glass'],0,FULL)
        box('Glass partition CUT',3.042,3.05,1.07,3.05,.02,1.20,M['glass'],0,CUT)
        box('Hinged glass door2600 FULL',3.012,3.02,.20,1.00,.012,2.612,M['glass'],0,FULL)
        box('Hinged glass door CUT',3.012,3.02,.20,1.00,.012,1.20,M['glass'],0,CUT)
        box('Door fixed transom FULL',3.012,3.02,.15,1.05,2.64,H-.025,M['glass'],0,FULL)
        # Curtain collected at the north end, shown low in the sectional illustration.
        for n in range(10):
            xx=2.93+.035*math.sin(n*2);yy=2.68+n*.035
            wall('Curtain pleat',xx-.025,xx+.025,yy-.021,yy+.021,H-.05,1.26,material=M['linen'])

def plant(x,y,z=0,scale=1):
    cyl('Ceramic planter',(x,y,z+.18*scale),.18*scale,.36*scale,M['pot'])
    for n in range(7):
        a=n*2.4;r=(.13+random.random()*.10)*scale
        sphere('Olive leaves',(x+math.cos(a)*r,y+math.sin(a)*r,z+(.5+random.random()*.25)*scale),(.16*scale,.065*scale,.22*scale),M['leaf'])

def table(name,x,y,r=.42,z=.75):
    cyl(name+' top',(x,y,z),r,.045,M['oak']);cyl(name+' pedestal',(x,y,z/2),.065,z,M['graphite']);cyl(name+' base',(x,y,.035),.24,.035,M['graphite'])

def chair(x,y,angle=0):
    o=cube('Upholstered dining chair',(x,y,.45),(.42,.43,.12),M['sage'],.065);o.rotation_euler.z=angle
    bx=x-math.sin(angle)*.16;by=y+math.cos(angle)*.16
    o=cube('Chair back',(bx,by,.70),(.41,.07,.43),M['sage'],.06);o.rotation_euler.z=angle
    for sx in [-1,1]:
      for sy in [-1,1]:
        dx=sx*.15;dy=sy*.15;xx=x+dx*math.cos(angle)-dy*math.sin(angle);yy=y+dx*math.sin(angle)+dy*math.cos(angle)
        cube('Chair leg',(xx,yy,.22),(.028,.028,.44),M['oak'],.006)

def kitchen():
    # Compact L-shaped kitchen within the original wet/service zone. No island.
    # North run 2.36 m and east return 1.55 m.
    for a,b in [(1.31,1.90),(1.91,2.49),(2.50,3.07),(3.08,3.63)]:
        box('Kitchen lower carcass',a,b,5.91,6.51,.10,.88,M['sage'],.006)
        box('Kitchen front',a+.008,b-.008,5.90,5.925,.13,.86,M['sage'],.006)
        box('Kitchen upper cabinet',a,b,6.15,6.50,1.55,2.64,M['ivory'],.006)
        box('Kitchen shadow handle',a+.035,b-.035,5.885,5.91,.825,.84,M['graphite'])
    box('Kitchen north stone worktop',1.30,3.64,5.87,6.52,.885,.92,M['stone'],.007)
    for a,b in [(5.33,5.90)]:
        box('Kitchen return cabinet',3.02,3.63,a,b,.10,.88,M['sage'],.006)
        box('Kitchen return front',3.00,3.025,a+.008,b-.008,.13,.86,M['sage'],.006)
    box('Kitchen return stone worktop',2.99,3.64,5.31,5.92,.885,.92,M['stone'],.007)
    # Sink and induction hob retained within original kitchen.
    box('Inset sink dark outline',1.51,2.07,6.0,6.40,.92,.926,M['graphite'],.04)
    box('Inset sink bowl',1.55,2.03,6.04,6.36,.926,.930,M['metal'],.035)
    cyl('Tap',(1.79,6.44,1.055),.022,.29,M['metal'])
    box('Tap spout',1.77,1.81,6.28,6.45,1.18,1.22,M['metal'],.014)
    box('Induction hob',3.04,3.56,5.38,5.87,.923,.938,M['graphite'],.022)
    for x in [3.16,3.44]:
      for y in [5.50,5.75]:cyl('Induction ring',(x,y,.939),.085,.003,M['cook'])
    box('Fridge tall enclosure',3.05,3.65,4.73,5.33,.08,2.64,M['ivory'],.015)
    box('Fridge door horizontal reveal',3.045,3.055,4.74,5.32,.91,.925,M['graphite'])
    box('Fridge door handle',3.02,3.04,4.82,4.86,1.17,1.70,M['graphite'],.008)
    box('Folding dining work table',1.49,2.49,3.35,3.85,.735,.775,M['oak'],.014)
    cube('Table folding leg',(2.32,3.64,.37),(.028,.028,.73),M['graphite'],.004)
    chair(2.01,4.16,0)
    # Useful decorative accessories, kept off circulation routes.
    cyl('Wood tray',(2.60,6.11,.935),.16,.025,M['oak']);sphere('Green bowl',(2.60,6.11,.99),(.11,.11,.04),M['sage'])

def bathroom():
    # Same fixtures as 2D:1200x900 NW shower, NE vanity, west-fronted WC,
    # washing machine at SW with its loading door facing the clear room center EAST.
    box('Shower tray1200x900',4.22,5.42,5.53,6.43,.015,.07,M['ivory'],.02)
    box('Shower fixed screen',5.405,5.425,5.56,6.40,.07,2.1,M['glass'])
    cyl('Shower drain',(4.39,6.28,.075),.05,.008,M['metal'])
    cube('Shower rail',(4.24,6.15,1.43),(.025,.025,1.25),M['metal'])
    box('Shower overhead arm',4.24,4.53,6.135,6.165,2.02,2.05,M['metal'])
    cyl('Rainshower',(4.53,6.15,2.01),.095,.018,M['metal'])
    box('Concealed cistern east wall',6.70,6.89,5.03,5.63,.04,1.15,M['tilebath'],.009)
    sphere('Wall hung WC faces west',(6.39,5.33,.41),(.33,.21,.17),M['ceramic'])
    sphere('WC seat',(6.36,5.33,.54),(.29,.205,.035),M['ivory'])
    box('Flush plate',6.686,6.701,5.25,5.41,.92,1.02,M['metal'],.008)
    box('Vanity',5.65,6.55,5.97,6.43,.26,.84,M['oak'],.015)
    box('Vanity stone top',5.63,6.57,5.95,6.45,.84,.88,M['stone'],.008)
    sphere('Oval basin',(6.10,6.20,.89),(.275,.135,.075),M['ceramic'])
    box('Bathroom mirror',5.72,6.48,6.50,6.52,1.08,2.18,M['mirror'],.025)
    cyl('Vanity mixer',(6.10,6.38,1.01),.018,.24,M['metal'])
    box('Washing machine',4.22,4.82,4.85,5.45,.04,.89,M['ivory'],.02)
    o=cyl('Washing machine round door',(4.835,5.15,.47),.215,.035,M['graphite']);o.rotation_euler.y=math.pi/2
    o=cyl('Washing machine glass',(4.858,5.15,.47),.165,.018,M['glass']);o.rotation_euler.y=math.pi/2
    box('Laundry countertop',4.20,4.84,4.83,5.47,.89,.93,M['oak'],.008)
    cube('Towels',(4.51,5.12,1.0),(.30,.24,.13),M['linen'],.018)

def bedroom(v):
    box('Bed upholstered base',.60,2.40,.95,3.10,.10,.35,M['linen'],.07)
    box('Bed 1600 x 2000 mattress',.70,2.30,1.02,3.02,.35,.56,M['ivory'],.095)
    box('Bed headboard',.60,2.40,3.02,3.10,.18,1.05,M['linen'],.07)
    box('Duvet',.72,2.28,1.05,2.62,.54,.65,M['bedlinen'],.07)
    for x in [1.10,1.90]:cube('Sleeping pillow',(x,2.72,.68),(.66,.39,.16),M['ivory'],.08)
    box('Sage bed throw',.70,2.30,1.34,1.82,.645,.67,M['sagefabric'],.035)
    # Bed envelope1800x2150: side clearance0.60m and foot0.95m; shelves locally occupy head-end aisles.
    for x in [.38,2.61]:
        cube('Bedside shelf',(x,2.73,.53),(.32,.38,.055),M['oak'],.02)
        cyl('Bedside lamp base',(x,2.75,.59),.085,.02,M['graphite'])
        cyl('Bedside lamp stem',(x,2.75,.76),.011,.32,M['graphite'])
        cyl('Small fabric lamp shade',(x,2.75,.90),.12,.18,M['ivory'])
    # Bedroom foot passage along y=0..0.95 remains clear.
    if v=='A':
        plant(2.74,2.88,0,.62)

def living(v):
    # Clear center: sofa along east wall, no central coffee table.
    box('Living rug',3.78,6.32,.85,2.48,.022,.038,M['rug'],.025)
    box('Sofa plinth',6.00,6.84,.29,2.42,.11,.27,M['graphite'],.03)
    box('Sofa base',6.00,6.86,.25,2.46,.25,.51,M['sofa'],.075)
    box('Sofa back',6.65,6.92,.30,2.41,.49,.95,M['sofa'],.075)
    for y in [.29,2.40]:cube('Sofa arm',(6.45,y,.62),(.91,.18,.45),M['sofa'],.07)
    for y in [.83,1.78]:cube('Sofa seat',(6.27,y,.54),(.65,.88,.20),M['sofa'],.085)
    for y in [.80,1.82]:
        o=cube('Sofa back pillow',(6.60,y,.75),(.18,.72,.45),M['linen'],.06);o.rotation_euler.y=-.14
    o=cube('Olive accent cushion',(6.42,.59,.78),(.23,.40,.36),M['sagefabric'],.07);o.rotation_euler.y=-.25
    # Built-in storage along the south wall, stops before the sofa and bedroom doorway.
    for a,b in [(3.75,4.35),(4.36,4.98),(4.99,5.60)]:
        box('Wardrobe full height',a,b,.02,.60,.035,2.65,M['ivory'],.008)
        box('Wardrobe shadow handle',b-.035,b-.023,.598,.612,.95,1.60,M['graphite'],.005)
    # Standalone TV console prevents glass loading in option C.
    box('Low TV console',3.14,3.40,1.34,2.62,.06,.49,M['oak'],.012)
    # A 43 inch screen width along Y, normal points to the east.
    box('43 inch TV body',3.32,3.36,1.42,2.39,.63,1.18,M['graphite'],.012)
    box('43 inch TV display',3.361,3.366,1.443,2.368,.654,1.157,M['screen'],.005)
    for y in [1.61,2.20]:box('TV support stand',3.27,3.40,y-.022,y+.022,.49,.64,M['graphite'],.008)
    # Small side table only, outside the main path from hall to sleeping zone.
    cyl('Sofa side table',(5.74,2.28,.50),.17,.032,M['oak']);cyl('Side table leg',(5.74,2.28,.26),.018,.46,M['graphite'])
    cyl('Coffee cup',(5.74,2.28,.548),.035,.06,M['ceramic'])
    # Entry circulation from x5..5.9, y2.69 stays free.

def hall():
    # Shallow shoe unit at NE side, clear of bathroom and external entrance.
    box('Entry shoe cabinet',5.99,6.80,4.29,4.58,.08,.98,M['oak'],.012)
    box('Entry bench',4.59,4.94,3.05,3.50,.12,.46,M['oak'],.012)
    cube('Entry bench cushion',(4.76,3.275,.49),(.31,.42,.09),M['sagefabric'],.022)

def loggia():
    # Modest independent space; no radiator or removed facade wall.
    box('Loggia storage low',.21,1.17,6.02,6.49,.04,.48,M['oak'],.012)
    cube('Loggia bench cushion',(.69,6.23,.54),(.90,.42,.10),M['linen'],.02)
    plant(.75,3.72,0,.73)

def lighting_camera():
    scene=bpy.context.scene
    scene.world.color=(.8,.8,.8);scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.78,.80,.82,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.45
    def area(name,loc,power,size,target):
        bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    area('Large daylight source',(-5,-3,9),1900,7,(3,3,0));area('Soft ceiling fill',(4,3,10),1500,6,(3,3,0));area('North bounce',(2,8,6),650,5,(3,3,0))
    bpy.ops.object.camera_add(location=(-9.8,-13.2,31.0));cam=bpy.context.object;cam.name='CAMERA_AXONOMETRIC_CUTAWAY';cam.rotation_euler=(Vector((3.4,3.1,.35))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=11.15;scene.camera=cam
    # Saved interior cameras can be used after enabling full geometry and hiding cutaway walls.
    for name,loc,target in [('CAMERA_INTERIOR_LIVING',(5.2,.85,1.55),(3.1,2.45,1.35)),('CAMERA_INTERIOR_BEDROOM',(.45,.36,1.5),(1.62,2.8,1.15)),('CAMERA_INTERIOR_KITCHEN',(4.12,3.88,1.55),(2.6,5.90,1.30))]:
        bpy.ops.object.camera_add(location=loc);c=bpy.context.object;c.name=name;c.data.lens=22;c.rotation_euler=(Vector(target)-c.location).to_track_quat('-Z','Y').to_euler()
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.cycles.adaptive_threshold=.04
    scene.render.resolution_x=1400;scene.render.resolution_y=1320;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
    scene.render.threads_mode='FIXED';scene.render.threads=5
    scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.45
    scene.render.image_settings.color_mode='RGB'

def setup(v):
    global M,FULL,CUT
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    for datablock in list(bpy.data.materials):bpy.data.materials.remove(datablock)
    for c in list(bpy.data.collections):
        if c.name!='Collection':bpy.data.collections.remove(c)
    FULL=bpy.data.collections.new('01_FULL_ARCHITECTURE_enable_for_interior');bpy.context.scene.collection.children.link(FULL);FULL.hide_render=True;FULL.hide_viewport=True
    CUT=bpy.data.collections.new('02_CUTAWAY_ARCHITECTURE_hide_for_interior');bpy.context.scene.collection.children.link(CUT)
    M={'wall':natural('Warm white painted plaster',(.82,.80,.74),100,.77,.007),'ivory':mat('Warm ivory',(.78,.77,.71),.54),'door':mat('Flush door warm grey',(.69,.68,.62),.47),'oak':natural('Natural oak',(.48,.30,.16),3,.53,.008,True),'oakfloor':mat('Oak board joints',(.35,.25,.16),.6),'tile':natural('Kitchen and hall warm porcelain',(.64,.61,.53),70,.64,.004),'tilebath':natural('Bathroom limestone porcelain',(.60,.58,.51),80,.6,.004),'tilelog':natural('Loggia greige tile',(.46,.45,.40),80,.72,.004),'sage':mat('Dusty sage cabinet paint',(.32,.39,.30),.46),'stone':natural('Pale quartz worktop',(.74,.72,.65),90,.36,.002),'graphite':mat('Graphite powdercoat',(.035,.044,.042),.43,.2),'frame':mat('Warm dark bronze window frames',(.075,.07,.061),.38,.45),'glass':mat('Clear architectural glass',(.82,.91,.88),.08,0,.96),'metal':mat('Brushed steel',(.40,.43,.43),.24,.8),'cook':mat('Hob ring marking',(.20,.22,.22),.4,.5),'ceramic':mat('White ceramic',(.86,.87,.84),.19),'mirror':mat('Mirror',(.73,.77,.77),.025,1),'linen':natural('Sand linen weave',(.66,.59,.48),130,.9,.004),'bedlinen':natural('Cotton duvet',(.74,.72,.66),150,.93,.003),'sagefabric':natural('Sage woven textile',(.34,.42,.31),150,.91,.004),'sofa':natural('Oatmeal sofa bouclé',(.67,.63,.55),125,.91,.008),'rug':natural('Woven warm ivory rug',(.72,.69,.60),180,.95,.008),'pot':mat('Clay pot',(.50,.42,.31),.78),'leaf':mat('Olive green leaves',(.17,.25,.11),.64),'screen':mat('Dark quiet TV screen',(.015,.026,.031),.16,.28)}
    M['boards']=[natural('Oak floor shade %s'%i,(.50+i*.011,.345+i*.009,.205+i*.007),3,.61,.004,True)for i in range(7)]
    architecture(v);kitchen();bathroom();bedroom(v);living(v);hall();loggia();lighting_camera()
    # Neutral studio plane emphasizes the exact shape of the apartment cutaway.
    cube('Studio ground',(3,3,-.35),(200,200,.20),mat('Studio warm grey',(.77,.76,.72),.84))
    scene=bpy.context.scene;scene['project']='Sandy-kala 2, Astana | 40.7 m2 per scan | concept only';scene['variant']=v;scene['height_assumption_m']=H;scene['door_leaf_height_m']=2.6;scene['warning']='Not measured CAD. Junctions and openings schematic. Widened kitchen opening B/C conditional on engineering and approval. Loggia isolated.'
    scene['interior_render_switch']='Hide collection 02_CUTAWAY_ARCHITECTURE; unhide render and viewport collection 01_FULL_ARCHITECTURE; choose saved interior camera.'
    # Video-ready transforms and cameras are saved; this deliverable is a static concept, not a permit set.
    scene.render.filepath=os.path.join(OUT,'variant_%s_axonometric.png'%v)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'variant_%s.blend'%v))
    bpy.ops.render.render(write_still=True)

if __name__=='__main__':
    import sys
    vs=sys.argv[sys.argv.index('--')+1:] if '--'in sys.argv else ['A','B','C']
    for v in vs:setup(v)
