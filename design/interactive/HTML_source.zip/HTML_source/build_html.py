from pathlib import Path
import base64,json,mimetypes,subprocess
P=Path(__file__).resolve().parent
subprocess.run([str(P/'build/node_modules/.bin/esbuild'),str(P/'build/app.js'),'--bundle','--minify','--format=iife','--target=es2020','--outfile='+str(P/'build/app.bundle.js')],check=True)
def data(path):
 f=P/path;mime=mimetypes.guess_type(f.name)[0] or 'application/octet-stream'
 return 'data:'+mime+';base64,'+base64.b64encode(f.read_bytes()).decode()
m=json.loads((P/'materials_manifest.json').read_text())
out={'models':{},'materials':{},'credits':[]}
for v in ['A','C','D']:out['models'][v]=base64.b64encode((P/'models'/f'{v}.glb').read_bytes()).decode()
for key,item in m['materials'].items():
 out['materials'][key]={'repeat':[1/n for n in item.get('suggested_tile_metres',[1,1])]}
 for channel in ['color','normal','roughness','orm']:
  if item.get(channel):out['materials'][key][channel]=data(item[channel])
 out['credits'].append({'name':item['asset_name']+' · '+item['label_ru'],'author':item['creator'],'license':item['license'],'url':item['source'],'changes':'карты 512 px, преобразованы из KTX2; художественный масштаб'})
if m.get('environment'):
 e=m['environment'];out['environment']={'data':data(e['path'])};out['credits'].append({'name':e['asset_name'],'author':'Poly Haven / HDRI Haven','license':e['license'],'url':e['source'],'changes':'освещение иллюстрационное'})
shell=(P/'shell.html').read_text()
shell=shell.replace('Интерактивная концепция / вариант D','Интерактивная концепция')
shell=shell.replace('Габарит до верха трубы','Труба + запас 20 мм')
shell=shell.replace('step="0.1" value="3.2"','step="0.01" value="3.2"')
shell=shell.replace('id="door-warning"','id="door-warning"')
shell=shell.replace('<output id="door-warning"','<p id="floor-warning" class="plan-warning"></p><output id="door-warning"')
shell=shell.replace('Расчёт габарита трубы — не конструкция стяжки.','Принят наружный диаметр 50 мм и условный запас 20 мм. Уклоны 2–3% — расчётные сценарии, не подтверждённый норматив. Высота модели условно 2,86 м; калькулятор проверяет другие отметки. Расчёт габарита трубы — не конструкция стяжки.')
shell=shell.replace('Эскиз варианта D. Кухня рядом с санузлом уменьшает длину труб.','Для D показан условный путь от новой кухни к санузлу. У A/C кухня остаётся на месте.')
shell=shell.replace('Не подключать кухонный зонт к туалетному каналу без подтверждённого проектного решения.','Подключение кухонного зонта к каналу санузла в этом предложении не предусмотрено.')
shell=shell.replace('конструкция плиты, стояк','тип плиты, конструктивная схема, стояк')
shell=shell.replace('Цена','Цена')
# Keep source and application within a single document for file:// access.
script=(P/'build/app.bundle.js').read_text().replace('</script','<\\/script')
block='<script id="project-data" type="application/json">'+json.dumps(out,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')+'</script>\n<script>'+script+'</script>'
license_text=(P/'build/node_modules/three/LICENSE').read_text()
html=shell.replace('</body>',block+'\n<!-- Three.js license\n'+license_text.replace('--','—')+'\n-->\n</body>')
# Normalize trailing spaces in the shell and bundled GLSL shader lines.
html='\n'.join(line.rstrip() for line in html.split('\n'))
(P/'Apartment_3D.html').write_text(html)
print('Standalone HTML bytes:',len(html.encode()))
