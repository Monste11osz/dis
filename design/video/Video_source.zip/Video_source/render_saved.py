#!/usr/bin/env python3
"""Render the archived camera scenes without the original modelling scripts.

Run with Blender 4.3, for example:
    blender -b -t 5 --python-exit-code 1 --python render_saved.py -- a c
Paths are relative to this file. Completed PNGs are reused on subsequent runs.
"""

from pathlib import Path
import struct
import sys
import time
import zlib

import bpy

ROOT = Path(__file__).resolve().parent
SHOTS = {"a": 72, "b": 72, "c": 72, "bedroom": 64, "door": 56}
LIGHT = ROOT / "architectural.sl"


def completed_png(path, width=960, height=720):
    """Reject truncated/wrong-size PNGs; check all chunk CRCs through IEND."""
    try:
        with path.open("rb") as source:
            if source.read(8) != b"\x89PNG\r\n\x1a\n":
                return False
            seen_header = False
            seen_data = False
            while True:
                header = source.read(8)
                if len(header) != 8:
                    return False
                length, kind = struct.unpack(">I4s", header)
                if length > 64 * 1024 * 1024:
                    return False
                payload = source.read(length)
                checksum = source.read(4)
                if len(payload) != length or len(checksum) != 4:
                    return False
                expected_crc = struct.unpack(">I", checksum)[0]
                if zlib.crc32(payload, zlib.crc32(kind)) & 0xFFFFFFFF != expected_crc:
                    return False
                if not seen_header and kind != b"IHDR":
                    return False
                if kind == b"IHDR":
                    if seen_header or length != 13:
                        return False
                    png_width, png_height = struct.unpack(">II", payload[:8])
                    if (png_width, png_height) != (width, height):
                        return False
                    seen_header = True
                elif kind == b"IDAT":
                    seen_data = True
                elif kind == b"IEND":
                    return seen_header and seen_data and length == 0 and source.read(1) == b""
    except (OSError, ValueError, struct.error):
        return False


def render_shot(name):
    scene_path = ROOT / "scenes" / f"{name}.blend"
    if not scene_path.is_file():
        raise FileNotFoundError(f"Missing saved scene: {scene_path}")
    bpy.ops.wm.open_mainfile(filepath=str(scene_path))
    scene = bpy.context.scene
    if (scene.frame_start, scene.frame_end) != (1, SHOTS[name]):
        raise ValueError(f"Unexpected frame range in {scene_path.name}; expected 1–{SHOTS[name]}")
    if scene.render.fps != 8 or scene.render.fps_base != 1:
        raise ValueError(f"Unexpected frame rate in {scene_path.name}; expected 8 fps")
    if scene.render.engine != "BLENDER_WORKBENCH":
        raise ValueError(f"Unexpected render engine in {scene_path.name}; expected Workbench")
    scene.display.shading.studio_light = LIGHT.name
    scene.render.resolution_x = 960
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGB"
    scene.render.use_file_extension = True
    folder = ROOT / "frames" / name
    pending = folder / ".pending"
    pending.mkdir(parents=True, exist_ok=True)
    reused = 0
    rendered = 0
    for frame in range(scene.frame_start, scene.frame_end + 1):
        destination = folder / f"{frame:04d}.png"
        if completed_png(destination):
            reused += 1
            continue
        temporary = pending / destination.name
        scene.frame_set(frame)
        scene.render.filepath = str(temporary)
        started = time.monotonic()
        bpy.ops.render.render(write_still=True)
        if not completed_png(temporary):
            raise RuntimeError(f"Renderer did not produce a complete 960 × 720 PNG: {temporary}")
        temporary.replace(destination)
        rendered += 1
        print(f"RENDER {name} {frame}/{scene.frame_end}: {time.monotonic() - started:.2f} s", flush=True)
    print(f"DONE {name}: {rendered} rendered, {reused} existing complete frames reused", flush=True)


def main():
    arguments = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if arguments in (["-h"], ["--help"]):
        print("Usage: blender -b --python render_saved.py -- [a b c bedroom door]")
        return
    names = list(dict.fromkeys(arguments or SHOTS))
    unknown = [name for name in names if name not in SHOTS]
    if unknown:
        raise ValueError(f"Unknown shots: {', '.join(unknown)}; choose from {', '.join(SHOTS)}")
    if not LIGHT.is_file():
        raise FileNotFoundError(f"Missing studio lighting preset: {LIGHT}")
    if not any(light.name == LIGHT.name for light in bpy.context.preferences.studio_lights):
        bpy.context.preferences.studio_lights.load(str(LIGHT), "STUDIO")
    for name in names:
        render_shot(name)


if __name__ == "__main__":
    main()
