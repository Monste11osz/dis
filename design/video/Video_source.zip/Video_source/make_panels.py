#!/usr/bin/env python3
"""Generate transparent editorial overlays for the apartment's 3D film."""

from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "panels"
OUT.mkdir(exist_ok=True)
WIDTH, HEIGHT, PANEL = 1280, 720, 320
SCALE = 2
PAPER = "#f3f0e9"
INK = "#253c32"
TEXT = "#48584e"
MUTED = "#788277"
RULE = "#d5d8cf"
FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")

SEGMENTS = {
    "a": {
        "number": "01", "eyebrow": "ВАРИАНТ A",
        "title": ["Открытая", "спальня"],
        "body": ["Кухня отдельно.", "Спальная зона открыта.", "Без новой перегородки."],
        "positive": ("ПРОСТРАНСТВО", "Больше открытой площади"),
        "constraint": ("УЧЕСТЬ", "Спальная зона без изоляции"),
    },
    "b": {
        "number": "02", "eyebrow": "ВАРИАНТ B",
        "title": ["Закрытая", "спальня"],
        "body": ["Спальня у окна.", "Гостиная без прямого окна.", "Проход к кухне — условный."],
        "positive": ("ПРИВАТНОСТЬ", "Отдельная спальня"),
        "constraint": ("УЧЕСТЬ", "Проход требует проверки стены и согласования"),
    },
    "c": {
        "number": "03", "eyebrow": "ВАРИАНТ C",
        "title": ["Стекло", "и штора"],
        "body": ["Стеклянная перегородка.", "Штора — для приватности.", "Заимствованный свет.", "Проход к кухне — условный."],
        "positive": ("ЗОНИРОВАНИЕ", "Гибкое разделение пространства"),
        "constraint": ("УЧЕСТЬ", "Проверить стену, проход и освещённость"),
    },
    "bedroom": {
        "number": "04", "eyebrow": "ДЕТАЛЬ / СПАЛЬНЯ",
        "title": ["Пространство", "спальни"],
        "title_size": 27,
        "body": ["Матрас 160 × 200 см.", "По бокам ≈60 см до корпуса.", "Шторы и приборы не учтены.", "Размеры условные."],
        "positive": ("РАССТАНОВКА", "Кровать у окна"),
        "constraint": ("УЧЕСТЬ", "Уточнить проходы после выбора мебели"),
    },
    "door": {
        "number": "05", "eyebrow": "ДЕТАЛЬ / ДВЕРЬ",
        "title": ["Дверь", "2,60 м"],
        "title_size": 34,
        "body": ["Полотно — 2,60 м.", "Проём — по выбранной системе.", "Чистая высота 2,86 м —", "допущение модели."],
        "positive": ("ПРОПОРЦИЯ", "Высокое полотно"),
        "constraint": ("УТОЧНИТЬ", "Перемычку и отметку чистого пола"),
    },
}


def font(size, bold=False):
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return ImageFont.truetype(str(FONT_DIR / name), round(size * SCALE))


def xy(value):
    return tuple(round(v * SCALE) for v in value)


layout_records = {}


for key, data in SEGMENTS.items():
    canvas = Image.new("RGBA", (WIDTH * SCALE, HEIGHT * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((0, 0, PANEL * SCALE - 1, HEIGHT * SCALE - 1), fill=PAPER)
    records = []

    def text(label, pos, size, bold=False, fill=TEXT, zone="panel"):
        position = xy(pos)
        chosen_font = font(size, bold)
        bounds = draw.textbbox(position, label, font=chosen_font, anchor="lt")
        bounds = [v / SCALE for v in bounds]
        if zone == "panel":
            assert 28 <= bounds[0] and bounds[2] <= 292, (key, label, bounds)
            assert 20 <= bounds[1] and bounds[3] <= 696, (key, label, bounds)
        else:
            assert 344 <= bounds[0] and bounds[2] <= 1256, (key, label, bounds)
            assert 665 <= bounds[1] and bounds[3] <= 704, (key, label, bounds)
        draw.text(position, label, font=chosen_font, fill=fill, anchor="lt")
        records.append({"text": label, "bbox": bounds, "zone": zone})

    def rule(y):
        draw.line(xy((28, y, 292, y)), fill=RULE, width=SCALE)

    def wrap(label, size=14, width=240):
        rows = []
        current = ""
        for word in label.split():
            candidate = (current + " " + word).strip()
            if draw.textlength(candidate, font=font(size)) / SCALE <= width:
                current = candidate
            else:
                if current:
                    rows.append(current)
                current = word
        if current:
            rows.append(current)
        return rows

    def note(label, body, y, positive=False):
        draw.line(xy((28, y, 28, y + 57)), fill=INK if positive else RULE, width=3 * SCALE)
        text(label, (40, y), 10.5, bold=True, fill=INK if positive else MUTED)
        for index, line in enumerate(wrap(body, width=249)):
            text(line, (40, y + 22 + 20 * index), 13.5)

    text("ЖК САНДЫ-КАЛА 2", (28, 33), 15, bold=True, fill=INK)
    text("АСТАНА", (28, 61), 11, fill=MUTED)
    rule(100)
    text(data["eyebrow"], (28, 128), 11, bold=True, fill=INK)
    title_size = data.get("title_size", 31)
    for i, line in enumerate(data["title"]):
        text(line, (28, 168 + i * 43), title_size, bold=True, fill=INK)
    for i, line in enumerate(data["body"]):
        text(line, (28, 293 + i * 25), 14)
    note(*data["positive"], 435, positive=True)
    note(*data["constraint"], 532)
    rule(641)
    text("КОНЦЕПЦИЯ / 3D", (28, 669), 10.5, bold=True, fill=MUTED)
    text(data["number"] + " / 05", (224, 668), 14, bold=True, fill=INK)

    # The right-hand area remains transparent except for the small caption ribbon.
    draw.rounded_rectangle(xy((344, 665, 1256, 704)), radius=4 * SCALE, fill=(243, 240, 233, 225))
    text("Эскизная 3D-концепция · размеры требуют обмера", (360, 678), 14, fill=INK, zone="ribbon")
    image = canvas.resize((WIDTH, HEIGHT), Image.Resampling.LANCZOS)
    # Keep the architectural side panel exactly opaque after antialiasing.
    alpha = image.getchannel("A")
    alpha.paste(255, (0, 0, PANEL, HEIGHT))
    image.putalpha(alpha)
    image.save(OUT / f"{key}.png")
    assert image.mode == "RGBA" and image.size == (1280, 720)
    assert alpha.crop((0, 0, PANEL, HEIGHT)).getextrema() == (255, 255)
    assert alpha.getpixel((900, 350)) == 0
    layout_records[key] = records


(OUT / "text_bounds.json").write_text(json.dumps(layout_records, ensure_ascii=False, indent=2), encoding="utf-8")
preview = Image.new("RGB", (PANEL * len(SEGMENTS), HEIGHT), PAPER)
for i, key in enumerate(SEGMENTS):
    segment = Image.open(OUT / f"{key}.png")
    preview.paste(segment.crop((0, 0, PANEL, HEIGHT)), (PANEL * i, 0))
preview.save(OUT / "panels_preview.png")
print(f"Created {len(SEGMENTS)} 1280 × 720 RGBA overlays in {OUT}; all text bounds checked.")
