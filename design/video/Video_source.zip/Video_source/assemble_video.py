"""Assemble genuine camera-rendered 3D frames with Russian editorial panels."""
from pathlib import Path
import subprocess, json
import argparse
P=Path(__file__).resolve().parent
SHOTS=[('a',9,'A — Открытая спальня'),('b',9,'B — Закрытая спальня'),('c',9,'C — Стекло и штора'),('bedroom',8,'Пространство спальни'),('door',7,'Полотно двери 2600 мм')]
def run(cmd,log):
 with log.open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
def encode(name,duration):
 frames=sorted((P/'frames'/name).glob('*.png'))
 assert len(frames)==duration*8,(name,len(frames))
 clip=P/'clips'/f'{name}.mp4'
 filtering=f'[0:v]tpad=stop_mode=clone:stop_duration=0.5,minterpolate=fps=24:mi_mode=blend,trim=duration={duration},setpts=PTS-STARTPTS,pad=1280:720:320:0:color=0xf3f0e9[v];[v][1:v]overlay=0:0:shortest=1,format=yuv420p'
 if name=='a':filtering+=',fade=t=in:st=0:d=0.4'
 if name=='door':filtering+=f',fade=t=out:st={duration-.6}:d=0.6'
 filtering+='[out]'
 cmd=['ffmpeg','-y','-hide_banner','-filter_complex_threads','2','-framerate','8','-start_number','1','-i',str(P/'frames'/name/'%04d.png'),'-loop','1','-framerate','24','-i',str(P/'panels'/f'{name}.png'),'-filter_complex',filtering,'-map','[out]','-t',str(duration),'-an','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-r','24','-pix_fmt','yuv420p','-movflags','+faststart',str(clip)]
 run(cmd,P/'clips'/f'{name}.log');print('ENCODED',name,flush=True)
def join():
 clips=P/'clips';lines='\n'.join("file '"+name+".mp4'" for name,_,_ in SHOTS)
 (clips/'concat.txt').write_text(lines+'\n')
 meta=[';FFMETADATA1','title=Санды-кала 2 — 3D-концепция','artist=Apartment concept project','comment=Concept animation. Approximate geometry. Door leaf 2600 mm. Native 8 fps renders interpolated to 24 fps. No audio.']
 t=0
 for _,duration,title in SHOTS:
  meta+=['[CHAPTER]','TIMEBASE=1/1000',f'START={t*1000}',f'END={(t+duration)*1000}',f'title={title}'];t+=duration
 (clips/'chapters.txt').write_text('\n'.join(meta)+'\n',encoding='utf-8')
 out=P/'Sandy_Kala_2_3D.mp4'
 run(['ffmpeg','-y','-hide_banner','-f','concat','-safe','0','-i',str(clips/'concat.txt'),'-i',str(clips/'chapters.txt'),'-map','0:v','-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',str(out)],clips/'join.log')
 print('OUTPUT',out,out.stat().st_size,flush=True)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--shot',choices=[s[0] for s in SHOTS]);parser.add_argument('--join-only',action='store_true');a=parser.parse_args();(P/'clips').mkdir(exist_ok=True)
 if not a.join_only:
  for name,duration,_ in SHOTS:
   if a.shot is None or a.shot==name:encode(name,duration)
 if a.shot is None:join()
